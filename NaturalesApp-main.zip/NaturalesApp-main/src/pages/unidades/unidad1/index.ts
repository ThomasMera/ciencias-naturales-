export * from './LosTejidos';
export * from './EstructuraTrofica';
