export * from './FuerzaGravitacional';
export * from './SistemaSolar';
